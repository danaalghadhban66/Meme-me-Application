//
//  MemeViewController.swift
//  MemeMe App V1.0
//
//  Created by Dana Alghadhban on 11/13/18.
//  Copyright © 2018 Dana Alghadhban. All rights reserved.
//

import UIKit
import Foundation


class MemeViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextFieldDelegate {

    @IBOutlet weak var cameraButton: UIBarButtonItem!
    @IBOutlet weak var albumButton: UIBarButtonItem!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var BottomText: UITextField!
    @IBOutlet weak var topText: UITextField!
    @IBOutlet weak var bottomToolbar: UIToolbar!
    let shareBnt = UIBarButtonItem(barButtonSystemItem: .action, target: self, action: #selector(shareImage))
    
   
    struct memeobj{
        var memeTopText: String
        var memeBottomText: String
        var originalImage: UIImage
        var memedImage: UIImage
        
    }
    
    let memeTextAttributes:[NSAttributedString.Key: Any] = [
        NSAttributedString.Key.strokeColor: UIColor.black,
        NSAttributedString.Key.foregroundColor: UIColor.white,
        NSAttributedString.Key.font: UIFont(name: "HelveticaNeue-CondensedBlack", size: 40)!,
        NSAttributedString.Key.strokeWidth: -4.5]
    
    func configure(textField :UITextField, withText text: String){
        textField.delegate = self
        textField.defaultTextAttributes = memeTextAttributes
        textField.textAlignment = NSTextAlignment.center
        textField.text = text
    }
        override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.navigationItem.leftBarButtonItem = shareBnt
        self.navigationItem.leftBarButtonItem?.isEnabled = false
            
            configure(textField: topText,withText: "Top")
            configure(textField: BottomText,withText: "Bottom")
    }


    func textFieldDidBeginEditing(_ textField: UITextField) {
        if ((textField.text == "Top") || (textField.text == "Bottom"))
        {textField.text = ""}
        
        if(textField == BottomText){
            subscribeToKeyboardNotifications()
        }
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        if(textField == BottomText){
             unsubscribeFromKeyboardNotifications()
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        subscribeToKeyboardNotifications()
        
        cameraButton.isEnabled = UIImagePickerController.isSourceTypeAvailable(.camera)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info [.originalImage] as? UIImage{
            imageView.image = image
        }
        dismiss(animated: true, completion: nil)
       
        self.navigationItem.leftBarButtonItem?.isEnabled = true
    }
    func presentImagePickerWith(sourceType: UIImagePickerController.SourceType) {
        let pickerController = UIImagePickerController()
        pickerController.delegate = self
        pickerController.sourceType = sourceType
        present(pickerController, animated:true, completion:nil)
    }
    @IBAction func pickAnImageFromAlbum(_ sender: Any) {
        presentImagePickerWith(sourceType: .photoLibrary)
    }
    @IBAction func pickAnImageFromCamera(_ sender: Any) {
        presentImagePickerWith(sourceType: .camera)
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
   override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
       // unsubscribeFromKeyboardNotifications()
    }

    @objc func keyboardWillShow(_ notification:Notification) {
        view.frame.origin.y = -getKeyboardHeight(notification)
    }
    
    @objc func keyboardWillHide(_ notification:Notification) {
        view.frame.origin.y = 0
    }
    func getKeyboardHeight(_ notification:Notification) -> CGFloat {
        
        let userInfo = notification.userInfo
        let keyboardSize = userInfo![UIResponder.keyboardFrameEndUserInfoKey] as! NSValue // of CGRect
        return keyboardSize.cgRectValue.height
    }
    func subscribeToKeyboardNotifications() {
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        
         NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    func unsubscribeFromKeyboardNotifications() {
        
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
         NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    func save(_ memedImage: UIImage) {
        
       let meme = memeobj(memeTopText: topText.text!, memeBottomText: BottomText.text!, originalImage: imageView.image!, memedImage: memedImage)
    }
    func toolbarState(hiddenBar:Bool){
        
        self.navigationController?.isNavigationBarHidden = hiddenBar
        bottomToolbar.isHidden = hiddenBar
    }
    func generateMemedImage() -> UIImage {
        toolbarState(hiddenBar: true)
        // Render view to an image
        UIGraphicsBeginImageContext(self.view.frame.size)
        view.drawHierarchy(in: self.view.frame, afterScreenUpdates: true)
        let memedImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        

        toolbarState(hiddenBar: false)
        return memedImage
    }
    @objc func shareImage(){
        let memedImage = generateMemedImage()
        let activityView = UIActivityViewController(activityItems: [memedImage], applicationActivities: nil)
        activityView.completionWithItemsHandler = {(activityType: UIActivity.ActivityType?, completed: Bool, returnedItems: [Any]?, error: Error?) in
            if !completed {
                
                return
            }
            
            self.save(memedImage)
            
        }
        self.present(activityView, animated: true, completion: nil)
       
        if let popOver = activityView.popoverPresentationController {
           popOver.sourceView = self.view
        }
    }
}

